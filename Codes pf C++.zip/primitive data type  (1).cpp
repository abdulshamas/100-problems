#include<iostream>
using namespace std;

int main()
{
int a;
cout<<"size of int"<<sizeof(a)<<endl;
float b;
cout<<"size of float"<<sizeof(b)<<endl;
char c;
cout<<"size of char"<<sizeof(c)<<endl;
bool d;
cout<<"size of bool"<<sizeof(d)<<endl;
 double e;
 cout<<"size of double"<<sizeof(e)<<endl;
return 0;
}