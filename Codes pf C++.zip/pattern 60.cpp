#include<iostream>
using namespace std;
int main (){ int n=1;
    for(int i=0;i<=5;i++){
    for(int j=0;j<=i;j++
   ){
    cout<<i%2<<" ";
    }
    cout<<endl;}
    return 0;}