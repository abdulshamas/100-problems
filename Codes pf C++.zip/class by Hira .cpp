#include<iostream>
using namespace std;
class student {
        public:
        string name="HIRA INAYAT";
        int rollnumber = 23;
        string uni = "B.G.N.U";
        
        void display()
        {
        cout<<"your name is::"<<name<<endl;
        cout<<" your roll number is::"<<rollnumber<<endl;
        cout<<" your university name is ::"<<uni<<endl;}
        };
          int main() {
          student s;
          s.display (); }
          