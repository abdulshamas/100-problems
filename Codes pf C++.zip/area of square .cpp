#include<iostream>
using namespace std;
int main(){ 
        int sides, area;
        cout<<"Enter the side of square"<<endl;
        cin>>sides;
        area=sides*sides;
        cout<<"the area of square is::"<<area<<endl;
        return 0;}