#include<iostream>
using namespace std;
int main(){
  int a,b,sum;
  cout<<"Enter a and b"<<endl;
  cin>>a>>b;
  sum= a-(-b);
  cout<<"your sum is::"<<sum<<endl;
  return 0;}