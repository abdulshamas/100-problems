#include<iostream>
using namespace std;
int main () {
   string name;
    cout<<"Enter name";
   // getline(cin,name);
   cin>>name;
    cout<<"your name is ::"<<name<<endl;
    return 0;}