#include<iostream>
#include<math.h>
using namespace std;
int main(){ 
        int sides;
        float area;
        cout<<"Enter the sides"<<endl;
        cin>>sides;
        area=(sqrt(5*(5+2*sqrt(5)))*sides*sides)/4;
        cout<<"the area of pantagone is::"<<area<<endl;
        return 0 ;}