#include<iostream>
using namespace std;
int sum() {
 return 0;
 }
  int main() {
 cout<<"hello word";
 }