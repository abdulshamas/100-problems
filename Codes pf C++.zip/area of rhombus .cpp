#include<iostream>
using namespace std;
int main(){ 
        int d1,d2, area;
        cout<<"Enter the diagonals of Rhombus"<<endl;
        cin>>d1>>d2;
        area=(d1*d2)/2;
        cout<<"the area of rhombus is::"<<area<<endl;
        return 0;}