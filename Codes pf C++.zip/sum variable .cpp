#include<iostream>
using namespace std;
int main() {
    int a,b,c;
    cout<<"Enter the value of a & b "<<endl;
    cin>>a>>b;
    c=a+b;
    cout<<"the sum of a and b is::"<<c<<endl;
    return 0;
}