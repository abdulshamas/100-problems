#include<iostream>
using namespace std;
int main () {
int n;
  cout<<"enter a  number"<<endl;
  cin>>n;
  (n%2==0)?cout<<"no is even":cout<<"no is odd";
  return 0;}