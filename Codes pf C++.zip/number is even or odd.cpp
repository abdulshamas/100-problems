#include<iostream>
using namespace std;
int main(){
int a;
    cout<<"Enter a number"<<endl;
    cin>>a;
    if(a%2==0){
    cout<<"the number is even" <<endl;}
    else {
    cout<<" the number is odd" ;}
    
    return 0;}