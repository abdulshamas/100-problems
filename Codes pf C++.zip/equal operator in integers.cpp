#include<iostream>
using namespace std;
int main(){
    int a,b;
    cout<<"Enter a and b"<<endl;
    cin>>a>>b;
    if(a==b){
    cout<<"a and b are equal";
    }else{
    cout<<"a and b are not equal";}
    return 0;}