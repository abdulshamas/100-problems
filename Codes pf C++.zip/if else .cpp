#include<iostream>
using namespace std;
int main (){
       int i;
       cout<<"Enter a number:"<<endl;
       cin>>i;
      if(i==0) {
      cout<<"press zero";
      } else {
      cout<<"zero is not press";}
       return 0;}