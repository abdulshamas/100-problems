#include<iostream>
using namespace std;
int main() {
     string str1,str2;
     cout<<"Enter first string"<<endl;
     cin>>str1;
     cout<<"Enter the second string"<<endl;
     cin>>str2;
     if(str1!=str2){
     cout<<"string is not equal";}
     else{
     cout<<"string is equal";}
     return 0;}