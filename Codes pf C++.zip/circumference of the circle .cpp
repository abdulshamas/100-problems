#include<iostream>
using namespace std;
int main(){
      int radius;
      float circumference;
     cout<<"Enter the radius of"<<endl;
     cin>>radius;
     circumference =2*3.14*radius;
     cout<<"the circumference of circle is::"<<circumference<<endl;
     return 0;}