#include<iostream>
using namespace std;
int main() {
     float frh,cel;
     cout<<"enter temperature in Fahrenheit"<<endl;
     cin>>frh;
     cel=(frh-32)*5/9;
     cout<<" Temperature in Fahrenheit::"<<frh<<endl;
     cout<<"Temperature in Celsius::"<<cel<<endl;
     return 0;}