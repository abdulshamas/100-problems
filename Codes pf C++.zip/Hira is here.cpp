#include<iostream>
using namespace std;
void greet() {
 cout<<"Hira is here"<<endl;
 }
 int main(){
 for(int i=1;i<=5;i++)
  greet();
  return 0;}