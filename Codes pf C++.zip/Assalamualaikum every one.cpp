#include<iostream>
using namespace std;
int main(){ 
      cout<<"Assalamualaikum! every one";
          return 0;}