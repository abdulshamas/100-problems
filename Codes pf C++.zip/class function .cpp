# include <iostream>
using namespace std;
class student{
public:
   int rollnumber;
  string name;
   string university;
   void display (){
   cout << name << endl;
   cout << rollnumber << endl;
   cout << university << endl;
   }
   };
   int main (){
   student s;
   s. name ="Hira Inayat";
   s.rollnumber = 23;
   s. university= "B.G.N.U";
   s. display();
   return 0;
   }