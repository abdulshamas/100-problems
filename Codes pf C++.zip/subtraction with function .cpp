#include<iostream>
using namespace std;
int sub(int a,int b) {
 return a-b;
 }
  int main() {
 cout<<sub(2,3)<<endl;
 }