#include<iostream>
using namespace std;
int divi(int a,int b) {
 return a/b;
 }
  int main() {
 cout<<divi(12,3)<<endl;
 }