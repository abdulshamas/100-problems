#include<iostream>
using namespace std;

int main()
{
int a;
cout<<"size of int"<<sizeof(a)<<endl;
float b;
cout<<"size of float"<<sizeof(b)<<endl;
char c;
cout<<"size of char"<<sizeof(c)<<endl;
bool d;
cout<<"size of bool"<<sizeof(d)<<endl;
short int si;
long int li;
cout<<"size of shortint"<<sizeof(si)<<endl;
cout<<"size of longint"<<sizeof(li)<<endl;
double e;
cout<<"size of double"<<sizeof(e)<<endl;
long double ld;
cout<<"size of long double"<<sizeof(ld)<<endl;
return 0;
}