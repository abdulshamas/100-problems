#include<iostream>
using namespace std;
int main (){
    int i=0;
    while (i !=1){
    cout<<"you are inside the while loop:"<<endl;
    cout<<"you are inside the while loop press 1 to exit from while loop"<<endl;
    cin>>i;} 
    cout<<"you are outside the while loop";
    return 0;
    }