#include<iostream>
using namespace std;
int main(){
      int radius;
      float area;
     cout<<"Enter the radius of"<<endl;
     cin>>radius;
     area =3.14*radius*radius;
     cout<<"the area of circle is::"<<area<<endl;
     return 0;}