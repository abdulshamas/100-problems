#include<iostream>
using namespace std;
int main (){
     char arr[2][5]{{'H','I','R','A'},{'A','M','I','N','A'}};
      for(int i=0;i<2;i++){
      for(int j=0;j<5;j++)
      {
      cout<<arr[i][j];}
      cout<<endl;}
      return 0;
      }