#include<iostream>
using namespace std;
void greet() {
 cout<<"Hira is here";
 }
 int main(){
  greet();
  return 0;}