#include<iostream>
using namespace std;
int main (){
    string str="HIRA INAYAT";
    cout<<"your string is::"<<str<<endl;
    return 0;}