#include<iostream>
using namespace std;
int main()
{
    string str1,str2;
    cout<<"Enter string"<<endl;
    cin>>str1;
    cout<<"Enter the string"<<endl;
    cin>>str2;
    if(str1==str2){
    cout<<"string is equal"<<endl;}
    else{
    cout<<"string is not equal"<<endl;}
    return 0;}