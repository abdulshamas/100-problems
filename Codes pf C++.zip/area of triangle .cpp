#include<iostream>
using namespace std;
int main(){
      int b,h;
      float area;
      cout<<"Enter the height and breadth"<<endl;
      cin>>b>>h;
       area=(b*h)/2;
       cout<<"the area of triangle is::"<<area<<endl;
       return 0;}