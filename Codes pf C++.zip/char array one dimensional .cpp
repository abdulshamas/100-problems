#include<iostream>
using namespace std;
int main (){
     char arr[4]{'H','I','R','A'};
      for(int i=0;i<4;i++)
      cout<<arr[i];
      return 0;
      }