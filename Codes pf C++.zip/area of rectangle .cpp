#include<iostream>
using namespace std;
int main(){
   int l, b,  area;
      cout<<"Enter the length and breadth"<<endl;
      cin>>b>>l;
       area=b*l;
       cout<<"the area of rectangle is::"<<area<<endl;
       return 0;}